# McLanFix

**免 mod 的 Minecraft 局域网联机补丁 —— 让离线账号也能进「对局域网开放」的世界，并且让樱花穿透有固定端口可指。**

适用于 Minecraft Java 版 **1.7 ~ 1.21.x**，原版 / Forge / Fabric / NeoForge 全部通用，**不需要安装任何 mod**。

---

## 1. 它解决什么问题

没有它的时候，你要用樱花穿透和朋友联机，会依次撞上三堵墙：

| 症状 | 原因 |
|---|---|
| `登录失败: Status: 429` / `无效会话` / `暂时无法连接到身份验证服务器` | 服务器在验证正版会话，离线账号过不去 |
| 朋友显示「无法连接至服务器」，但你能进 | 局域网端口每次随机，樱花隧道指向的固定端口上没人 |
| 服务器列表里那个世界带锁，点不进去 | 同上，服务器要求会话验证 |

LSP（`自定义局域网联机`）之所以是刚需，就是因为它一次解决了前两个问题。McLanFix 用**不装 mod 的方式**做同样的事。

## 2. LSP 到底做了什么

| LSP 的功能 | 本质 | McLanFix 是否覆盖 |
|---|---|---|
| **在线模式 / 离线模式开关** | 把集成服务器的 `online-mode` 关掉，跳过 Mojang 会话验证 | ✅ `McLanFix.jar`（JVM Agent） |
| **本地端口** | 覆盖「对局域网开放」用的随机端口 | ✅ 1.20+ 原版界面自带端口框；1.7~1.19.3 用 `tools/McLanPin.jar` |
| 最大玩家数（默认 8） | 改 `PlayerList.maxPlayers` | ❌ 暂不支持 |
| MOTD | 改局域网广播里的世界名 | ❌ 不需要（外网直连看不到 MOTD） |
| 离线模式 + UUID 修复 | 让离线玩家与正版玩家 UUID 不冲突 | ⚠️ 部分（见 §7） |

## 3. 原理：为什么它不用按版本编译

mod 之所以要“一个版本一个 jar”，是因为它依赖 Forge/Fabric 的 API 和该版本的映射表。
McLanFix 不碰这些，它是 **JVM Agent**——游戏启动时由 Java 直接加载，在类加载阶段改写 **Mojang 自己的 authlib**：

```
com.mojang.authlib.yggdrasil.YggdrasilMinecraftSessionService
  joinServer(...)      -> 直接返回（客户端不再向 Mojang 请求验证）
  hasJoinedServer(...) -> 直接返回玩家档案（服务端认为验证已通过）
```

authlib 是 Mojang 的库，**类名从不混淆、方法签名跨版本稳定**，所以一份补丁能通吃 1.7 ~ 1.21。
`authlib-injector`、各种皮肤站用的也是同一个原理，只是它们改写的是认证服务器地址。

## 4. 快速开始

### 4.0 先跑一次自检（推荐）

双击 **`检查补丁.bat`**：它会找一个可用的 Java、实际加载一次补丁，并把你该复制的那行参数打印出来。

- 看到 `[McLanFix] 已加载…` → 补丁本身没问题
- 提示找不到 Java → 先装 Java 8+

### 4.1 所有人（房主 + 访客）都要做：加载 McLanFix

PCL：**设置 → 启动 → 游戏 JVM 参数**，追加一行（路径改成你实际放的位置）：

```
-javaagent:D:\mc局域网\McLanFix\McLanFix.jar
```

HMCL：**版本设置 → 高级 → JVM 参数**，同样追加。

启动游戏后，日志里应出现：

```
[McLanFix] 已加载，正在关闭正版会话验证（离线联机模式）
[McLanFix]   替换 joinServer(...)
[McLanFix]   替换 hasJoinedServer(...)
```

看到这三行就说明补丁生效了。**不需要**再点任何“离线模式”开关。

### 4.2 端口（只对 1.19.3 及更早需要）

| 游戏版本 | 做法 |
|---|---|
| **1.20 及以上** | 原版「对局域网开放」界面**自带端口输入框**，直接填 `25565` |
| **1.7 ~ 1.19.3** | 双击 `tools\启动转发器.bat`，它会占住 `25565` 并自动跟随游戏的随机端口 |

> 转发器只做 TCP 搬运，不解析游戏协议，因此与版本无关。它会打印 `发现局域网端口 xxxxx`。

### 4.3 樱花穿透

| 项目 | 填写 |
|---|---|
| 隧道类型 | **TCP** |
| 本地 IP | `127.0.0.1` |
| 本地端口 | `25565`（与游戏/转发器一致） |
| 远程端口 | 让樱花分配 |

启动隧道后把 `节点域名:远程端口` 发给朋友，朋友在 MC 里「**直接连接**」输入。

## 5. 兼容性

| 项目 | 支持情况 |
|---|---|
| 游戏版本 | 1.7 ~ 1.21.x（含快照），原版 / Forge / Fabric / NeoForge / 整合包 |
| Java | 8 或更高（Agent 与 ASM 均按 Java 8 字节码编译） |
| 系统 | Windows / macOS / Linux（转发器的端口扫描兜底为 Windows 专用） |
| 正版账号 | 不需要 |

## 6. 验证与排错

| 现象 | 检查 |
|---|---|
| 日志没有 `[McLanFix]` | JVM 参数没生效：确认是“游戏 JVM 参数”而不是“游戏参数”；路径要绝对路径，含空格不用加引号 |
| 仍报 429 / 无效会话 | 访客端没加 `-javaagent`；或用了第三方登录（authlib-injector）叠加，先去掉 |
| 能进但朋友进不来 | 樱花隧道是否“运行中”；远程端口是否被占；本地端口是否与游戏一致 |
| 转发器提示端口被占 | 换 `--port 25566`，樱花本地端口同步改 |

## 7. 已知限制（如实说明）

1. **未在全部版本逐一实测**：agent 逻辑在真实 `authlib-4.0.43` 上离线验证通过（替换后 `hasJoinedServer` 直接返回档案、`joinServer` 零网络请求），但游戏内只做了 1.20.1 的目标验证，其它版本请以日志为准。
2. **不改变最大玩家数**（原版局域网上限 8）—— 需要更大请自行装 LSP/EasyLAN。
3. **UUID 冲突**：离线玩家与正版玩家同名时仍可能冲突，LSP 的“UUID 修复”未实现。
4. **不要用于公开服务器**：它关闭的是本地会话验证，公网服仍应保持正版验证。
5. 无 GUI：agent 是纯 JVM 参数，转发器是命令行窗口。

## 8. 目录结构

```
McLanFix/
  McLanFix.jar          JVM Agent（核心，所有人必装）
  检查补丁.bat          自检：验证补丁可加载，并打印要复制的参数
  tools/
    McLanPin.jar        固定端口转发器（仅 1.19.3 及更早需要）
    启动转发器.bat
    src/                转发器源码
  src/lanfix/Agent.java Agent 源码
  test/                 authlib 离线验证用例
  README.md
  LICENSE
```

## 9. 构建

```
# Agent（需要 ASM 9.x）
javac --release 8 -encoding UTF-8 -cp lib/asm-9.7.1.jar -d out src/lanfix/Agent.java
jar cfm McLanFix.jar manifest.txt -C out . -C lib-asm .

# 转发器
javac --release 8 -encoding UTF-8 -d out src/lanpin/*.java
jar cfe McLanPin.jar lanpin.Main -C out .
```

## 10. 许可

MIT。与 Mojang、Microsoft、樱花穿透均无隶属关系；Minecraft 是 Microsoft 的商标。
